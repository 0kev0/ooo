using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;
using System.Globalization;
using System.Linq;
namespace POKEMON_ver1
{
    public class charizard : fuego
    {
        public charizard() { }
        public charizard( string nombre, string debilidad, string tipo, double Hp, double speed, double def, bool disp)
        : base( nombre, debilidad, tipo, Hp, speed, def, disp)
        {
        }
        public charizard(string tipo, string debilidad)
        : base (tipo, debilidad)
        {
            
        }

        public charizard (string ataque, double dmg, string tipo)
        : base(ataque,dmg,tipo)
        {
        }

        /////////////////////////////////////ataques/////////////////////////////////////////////////////
        public static List<poke> atk1 = new List<poke>{
            new poke("Lanza LLamas", 80,"Fuego")
        };
        public static List<poke> atk2 = new List<poke>
        {
                new poke ("Colmillo igneo", 45,"Fuego")
        };

        public static List<poke> atk3 = new List<poke>{
        new poke ("Contra-ataque",40,"Fuego")
        };

        //////////////////////////////////////////STAST////////////////////////////////////////////////////
        public static List<poke> stats = new List<poke>{//(nombre, debilidad, Hp, speed, atk, def
        new poke("Charizard","Agua","Fuego",290,.10,.36, true)
        };
        //////////////////////////////////////////TIPO--DEBILIDAD///////////////////////////////////////
        public static List<poke> type = new List<poke>{//tipo---debilidad 
            new poke ("Fuego","Agua"),new poke ("Fuego","Tierra"),new poke ("Fuego","Roca")
        };

        //////////////////////////////////////////DICCIONARIO//////////////////////////////////////////////
        public static Dictionary<string, List<poke>> ALL = new Dictionary<string, List<poke>>{
            {"S",stats},
            {"D",type},
            {"1",atk1},
            {"2",atk2},
            {"3",atk3}
        };//ELIMINAR

        /////////////////////////////////////METODOS PARA RETORNAR COLECCIONES////////////////////////////////////////////////////
        public List<poke> stats_()//devuelve estadisticas 
        {
            return stats;  //estadisticas
        }
        public List<poke> type_()
        {
            return type;  //estadisticas
        }

        public List<poke> atk1_()
        {
            return atk1; //estadisticas
        }
        public List<poke> atk2_()
        {
            return atk2; //estadisticas
        }
        public List<poke> atk3_()
        {
            return atk3; //estadisticas
        }

        //***********************************************

        public virtual Dictionary<string, List<poke>> todo()
        {
            return ALL;
        }
        public virtual void vermain()
        {
            IEnumerable<poke> x = from a in ALL["S"] select a;
            IEnumerable<poke> xx = from a in ALL["1"] select a;
            IEnumerable<poke> xxx = from a in ALL["2"] select a;
            IEnumerable<poke> xxxx = from a in ALL["3"] select a;


            foreach (var q in x)
            {
                Console.WriteLine($"Pokemon {q.nombre} \t vida de {q.Hp} \t % atk {q.atk} \t def {q.def} \t {q.speed}");
            }
            foreach (var qq in xx)
            {
                Console.WriteLine($"\tataque 1 \t\t{qq.ataque}\t\t{qq.dmg}");
            }
            foreach (var qqq in xxx)
            {
                Console.WriteLine($"\tataque 2 \t\t{qqq.ataque}\t\t{qqq.dmg}");
            }
            foreach (var qqqq in xxxx)
            {
                Console.WriteLine($"\tataque 3 \t\t{qqqq.ataque}\t\t{qqqq.dmg}\n");
            }
        }
    }
}