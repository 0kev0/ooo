namespace POKEMON_ver1
{
    public class tierra : poke
    {
        public tierra() { }

        public tierra( string nombre, string debilidad, string tipo, double Hp, double speed, double def, bool disp)
        : base( nombre, debilidad, tipo, Hp, speed, def, disp)
        {
        }
        public tierra(string tipo, string debilidad)
        : base(tipo, debilidad)
        {
        }

        public tierra (string ataque, double dmg, string tipo)
        : base(ataque,dmg,tipo)
        {

        }

    }
}