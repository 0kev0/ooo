namespace POKEMON_ver1
{
    public class roca : poke
    {
        public roca() { }

        public roca ( string nombre, string debilidad, string tipo, double Hp, double speed, double def, bool disp)
        : base( nombre, debilidad, tipo, Hp, speed, def, disp)
        {
        }

                public roca(string tipo, string debilidad)
        : base(tipo, debilidad)
        {
        }

        public roca (string ataque, double dmg, string tipo)
        : base(ataque,dmg,tipo)
        {

        }
    }
}