namespace POKEMON_ver1
{
    public class electro : poke
    {
        public electro() { }

        public electro( string nombre, string debilidad, string tipo, double Hp, double speed, double def, bool disp)
        : base( nombre, debilidad, tipo, Hp, speed, def, disp)
        {
        }
        public electro(string tipo, string debilidad)
: base(tipo, debilidad)
        {
        }

        public electro (string ataque, double dmg, string tipo)
        : base(ataque,dmg,tipo)
        {

        }
    }
}