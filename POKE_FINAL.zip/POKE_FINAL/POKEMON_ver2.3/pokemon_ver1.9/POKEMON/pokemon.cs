using System;
using System.Collections.Generic;
using System.Runtime.InteropServices.ComTypes;
using System.Globalization;
using System.Linq;
namespace POKEMON_ver1
{
    public class poke
    {
        public string nombre;//nombre
        public double Hp;//vida
        public double def;//defensa
        public double atk;//ataque porcentaje de ataque
        public string debilidad;//debilidad
        public string ataque;//nombre de los ataques
        public double dmg;//damage
        public double speed;//velocidad
        public string tipo;//tipo de pokemon
        public bool disponible = true;

        ////////////////////////////////////////////CONSTRUCTORES/////////////////////////////////////////////////////////
        public poke() { }//CONSTRUCTOR SIN PARAMETROS
        public poke(string nombre, string debilidad, string tipo, double Hp, double speed, double def, bool disp)
        {
            this.nombre = nombre;
            this.Hp = Hp;
            this.speed = speed;
            this.def = def;
            this.debilidad = debilidad;
            this.tipo = tipo;
            this.disponible = disp;
        }

        public poke(string tipo, string debilidad)//constructor para tipo y debilidad para atk efectivos
        {
            this.tipo = tipo;
            this.debilidad = debilidad;

        }
        public poke(string ataque, double dmg, string tipo)//constructor para colecciones de ataques
        {
            this.ataque = ataque;
            this.dmg = dmg;
            this.tipo = tipo;
        }

        ////////////////////////////////////////////METODOS////////////////////////////////////////////////////////////       

        public bool cambio1(Dictionary<string, List<poke>> a, bool cambioA)//CONDICIONAL SI SIGUE O NO EL COMBATE
        {
            int op;
            Console.WriteLine($"**************************************************************************************");
            Console.WriteLine($"**************************************************************************************\n\n");

            IEnumerable<poke> aax = from x in a["S"] select x;
            foreach (var aa in aax)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"{aa.nombre} le resta {aa.Hp} puntos de vida");

                do
                {
                    Console.WriteLine($"\nDesean cambiar de pokemon");
                    Console.WriteLine("\n\t1=si\t\t2=no");
                    Console.ForegroundColor = ConsoleColor.White;
                    op = Convert.ToInt32(Console.ReadLine());

                    if (op == 1)
                    {
                        Console.Clear();
                        /*Si elige que si el cambio sera False, permitiendole al entrenador realizar su cambio de pokemon*/
                        cambioA = false; return cambioA;
                    }

                    if (op <= 0 || op > 2)
                    {
                        Console.WriteLine("Ha lanzado un dato incorecto, porfavor vuelva a elegir\n\n");
                    }

                    Console.WriteLine($"**************************************************************************************");
                    Console.WriteLine($"**************************************************************************************\n");

                    /*Si elige que no entonces retornara un True, confirmando que el entrenador no desea hacer un cambio de pokemon*/
                    cambioA = true; return cambioA;
                } while (op <= 0 || op > 2);

            }
            return true;

        }

        public bool cambio2(Dictionary<string, List<poke>> b, bool cambioB)//CONDICIONAL SI SIGUE O NO EL COMBATE
        {
            Console.WriteLine($"Desean cambiar de pokemon"); int op = 0;
            IEnumerable<poke> aax = from x in b["S"] select x;
            foreach (var aa in aax)
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"{aa.nombre} le resta {aa.Hp} puntos de vida");

                do
                {
                    Console.WriteLine("\n\t1=si\t2=no");
                    Console.ForegroundColor = ConsoleColor.White;
                    op = Convert.ToInt32(Console.ReadLine());
                    if (op == 1)
                    {
                        /*Si elige que si el cambio sera False, permitiendole al entrenador realizar su cambio de pokemon*/
                        cambioB = false; return cambioB;
                    }
                    if (op <= 0 || op > 2)
                    {
                        Console.WriteLine("Ha lanzado un dato incorecto, porfavor vuelva a elegir\n\n");
                    }

                    cambioB = true; return cambioB;
                } while (op <= 0 || op > 2);
            }
            /*Si elige que no entonces retornara un True, confirmando que el entrenador no desea hacer un cambio de pokemon*/
            return true;
        }

        public void petateado(Dictionary<string, List<poke>> a, Dictionary<string, List<poke>> b, bool y)//CONDICIONAL SI SIGUE O NO EL COMBATE
        {//PRUEBEN USAR SOLO ESTE, SIN EL METODO EXIT(), SI SIRVE SOLO ESTE BORREN EL METODO EXIT
            IEnumerable<poke> aax = from x in a["S"] select x;
            IEnumerable<poke> bbx = from x in b["S"] select x;
            foreach (var aa in aax)
            {
                foreach (var bb in bbx)
                {
                    if (aa.Hp < 1)
                    {//MANO DE GATO
                        Console.WriteLine($"Upss");
                        Console.WriteLine($">{aa.nombre} no  puede seguir\n");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"\nGANA {bb.nombre}");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    if (bb.Hp < 1)
                    {//MANO DE GATO
                        Console.WriteLine($"Upss");
                        Console.WriteLine($">{bb.nombre} no  puede seguir");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine($"\nGANA {aa.nombre}");
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                }
            }
        }

        public bool exit(Dictionary<string, List<poke>> a, Dictionary<string, List<poke>> b, bool y)//salir de pelea
        {
            IEnumerable<poke> aax = from x in a["S"] select x;
            IEnumerable<poke> bbx = from x in b["S"] select x;
            foreach (var aa in aax)
            {
                foreach (var bb in bbx)
                {
                    if (aa.Hp < 1)
                    {
                        Console.ReadKey();

                        return y = false;
                    }
                    if (bb.Hp < 1)
                    {
                        Console.ReadKey();

                        return y = false;
                    }
                }
            }
            return y = true;
        }

        public double crit(double crt)//METODO DETERMINAR SI HABRA O NO UN GOLPE CRITICO
        {
            Random rnd = new Random();
            if (rnd.Next(1, 10) > 6)
            {
                crt = 2; return crt;
            }
            else
            {
                crt = 1; return crt;
            }
        }

        /* Efectivo del pokemon del entrenador 1 */
        public double EFECTIVOa(Dictionary<string, List<poke>> a, Dictionary<string, List<poke>> b, double efe)//determinar si hubo golpe efectivo
        {
            IEnumerable<poke> aax = from x in a["1"] select x;

            IEnumerable<poke> bbb = from x in b["D"] select x;
            foreach (var atk in aax)
            {
                foreach (var def in bbb)
                {
                    if (atk.tipo == def.debilidad)
                    {
                        efe = 1.25; return efe;
                    }

                }


            }
            return efe;
        }

        /* Efectivo del pokemon del entrenador 2 */
        public double EFECTIVOb(Dictionary<string, List<poke>> b, Dictionary<string, List<poke>> a, double efe)//determinar si hubo golpe efectivo
        {
            IEnumerable<poke> aax = from x in b["1"] select x;

            IEnumerable<poke> bbb = from x in a["D"] select x;
            foreach (var atk in aax)
            {
                foreach (var def in bbb)
                {
                    if (atk.tipo == def.debilidad)
                    {
                        efe = 1.25; return efe;
                    }

                }


            }
            return efe;
        }

        public void alerta(double crt, double efe)
        {
            if (crt == 2)
            {//MANO DE GATO
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine($"\t¡¡¡GOLPE CRITICO +200%¡¡¡");
                Console.ForegroundColor = ConsoleColor.White;
            }
            if (efe == 1.25)
            {//MANO DE GATO
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine($"\t¡¡¡GOLPE EFECTIVO +25%¡¡¡");
                Console.ForegroundColor = ConsoleColor.White;
                {

                };
            }
            if (crt == 2 && efe == 1.25)
            {//MANO DE GATO
                Console.ForegroundColor = ConsoleColor.DarkGreen; Console.WriteLine($"\tGOLPE SUPEREFECTIVO!!!!!"); Console.ForegroundColor = ConsoleColor.White;
            }
        }
        public void prueba_ataque()
        {
            Dictionary<string, List<poke>> a; Dictionary<string, List<poke>> b;
            string namea; string nameb;
            /* Objetos creados */
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\nIngrese su nombre:");
            Console.WriteLine("___________________________________");
            namea = Console.ReadLine();
            entrenador ash = new entrenador(namea);
            Console.WriteLine($"Entrenedor 1 es:  {ash.nombre}");

            Console.ForegroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.WriteLine("\nIngrese su nombre:");
            Console.WriteLine("___________________________________");
            nameb = Console.ReadLine();
            entrenador red = new entrenador(nameb);
            Console.WriteLine($"Entrenedor 2 es:  {red.nombre}");


            var i = 1; var ii = 1;//contadores


            bool EXIT = true;
            do
            {
                bool cambioA = true; bool cambioB = true; bool relevo = true;

                do
                {
                    /* Se inicializan o se mandan a llamar metodos mediante los objetos */
                    a = ash.SELECION_DE_PELEADORa();
                    b = red.SELECION_DE_PELEADORb();

                    Console.ReadKey();
                    Console.ForegroundColor = ConsoleColor.Blue;
                    Console.WriteLine($"********************************************************************************************");
                    IEnumerable<poke> aax = from x in a["S"] select x;
                    IEnumerable<poke> bbx = from x in b["S"] select x;
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine($"\t\tESTADISTICAS DE LOS POKEMONES SELECCIONADOS\n\n");

                    foreach (var itemA in aax)//MANO DE GATO
                    {
                        Console.WriteLine($"Nombre: {itemA.nombre}\t Vida: {itemA.Hp}\t Debilidad: {itemA.debilidad}\t  velocidad: {itemA.speed}");
                    }
                    foreach (var itemB in bbx)//MANO DE GATO
                    {
                        Console.WriteLine($"Nombre: {itemB.nombre}\t Vida: {itemB.Hp}\t Debilidad: {itemB.debilidad}\t  velocidad: {itemB.speed}\n");
                    }
                    Console.WriteLine($"********************************************************************************************\n");

                    double crt = 1;//variable para calculo de critico
                    double efe = 1;//variable para calculo de efecttivo

                    bool y = true;
                    foreach (var aa in a["S"])//cha blas
                    {
                        foreach (var bb in b["S"])
                        {
                            while (exit(a, b, y) == true)
                            {
                                Console.WriteLine($"\n\t\tCOMIENZA RONDA: {i++}!!");//ronda empieza
                                                                                    //debilidades(a, b);
                                if (aa.speed > bb.speed)//CONDICIONAL DE QUIEN ATACA PRIMERO
                                {//MANO DE GATO
                                            Console.WriteLine($"turno para: {ash.nombre}");



                                    Console.WriteLine($"\n********************************************************************************************\n");
                                    Console.WriteLine($"\t{aa.nombre} es mas rapido que {bb.nombre}                                ");
                                    Console.WriteLine($"\t{aa.nombre} ataca de primero                                             \n");
                                    Console.WriteLine($"********************************************************************************************\n");
                                    Console.WriteLine($"TURNO {ii++}\n");
                                    Console.WriteLine($"********************************************************************************************\n");
                                    Console.WriteLine($"Seleccione su ataque:");
                                    Console.WriteLine("_____________________________________________________________________________________________\n");

                                    foreach (var atk in ash.SELECT_ATAQUE(a))//usa la lista del ataque seleccionado por el metodo selectATACK()
                                    {
                                        crt = crit(crt);
                                        efe = EFECTIVOa(a, b, efe);


                                        Console.ForegroundColor = ConsoleColor.White;
                                        Console.WriteLine($"{aa.nombre} ataca con {atk.ataque} que hace un daño de {atk.dmg}\n");
                                        Console.WriteLine($"DAÑO TOTAL:  {atk.dmg * efe * crt} !!!\nREVISAR CRIT{crt}");//si hay criticp p efectivo se agraga                                                                                  //                                  CONDICIONAL DI HUBO O NO CRITICO/EFECTIVO
                                        Console.WriteLine($"\tRevisar efectivo:  {efe}");
                                        alerta(crt, efe);
                                        //MANO DE GATO
                                        Console.WriteLine($"{bb.nombre} tiene defensa de {bb.def} \n");//RECIBE ATAQUE
                                        Console.WriteLine($"Reduce el ataque de {atk.dmg * efe * crt} en {atk.dmg * efe * crt - (atk.dmg * efe * crt * bb.def)}");
                                        Console.WriteLine($"La vida de {bb.nombre} se reduce a {Math.Round(bb.Hp = bb.Hp - (atk.dmg * efe * crt - (atk.dmg * efe * crt * bb.def)))}\n");
                                        crt = 1; efe = 1;//REESTALECER VALORES DE CRITICO Y EFECCTIVO

                                    }
                                    if (aa.Hp <= 0)
                                    {
                                        ash.endA();

                                    }
                                    if (bb.Hp <= 0)
                                    {
                                        red.endB();
                                    }
                                    petateado(a, b, y); y = exit(a, b, y);

                                    if (y == false)
                                    {
                                        break;
                                    }
                                    //Cambio_POKEMON(a,b,a);

                                    foreach (var atkb in red.SELECT_ATAQUE(b))//turno b
                                    {
                                                    Console.WriteLine($"turno para:  {red.nombre}");

                                        crt = crit(crt);
                                        efe = EFECTIVOa(b, a, efe);

                                        Console.WriteLine($"\nDAMAGE TOTAL: {atkb.dmg * efe * crt}\n\n ");
                                        alerta(crt, efe);
                                        //MANO DE GATO
                                        Console.WriteLine($"{aa.nombre} tiene defensa de {aa.def} \n");
                                        Console.WriteLine($"Reduce el ataque de {atkb.dmg * efe * crt} en {Math.Round(atkb.dmg * efe * crt - (atkb.dmg * efe * crt * aa.def))}\n");
                                        Console.WriteLine($"La vida de {aa.nombre} se reduce a {Math.Round(aa.Hp = aa.Hp - (atkb.dmg * efe * crt - (atkb.dmg * efe * crt * aa.def)))}\n");
                                        crt = 1; efe = 1;//REESTALECER VALORES DE CRITICO Y EFECCTIVO

                                    }
                                    if (aa.Hp <= 0)
                                    {
                                        ash.endA();

                                    }
                                    if (bb.Hp <= 0)
                                    {
                                        red.endB();
                                    }
                                    petateado(a, b, y); y = exit(a, b, y);
                                    if (y == false)
                                    {
                                        break;
                                    }

                                    cambioA = cambio1(a, cambioA);
                                    if (cambioA == false)
                                    {
                                        Console.WriteLine($"cambio de pokemon!!!");
                                        break;
                                    }
                                    cambioB = cambio2(b, cambioB);
                                    if (cambioB == false)
                                    {
                                        Console.WriteLine($"cambio de pokemon!!!");
                                        break;
                                    }

                                }

                                if (bb.speed > aa.speed)
                                {
                                                Console.WriteLine($"turno para:  {red.nombre}");

                                    Console.WriteLine($"********************************************************************************************\n\n");
                                    Console.WriteLine($"\t{bb.nombre} es mas rapido que {aa.nombre}");
                                    Console.WriteLine($"\t{bb.nombre} ataca de primero\n");
                                    Console.WriteLine($"********************************************************************************************\n\n");
                                    Console.WriteLine($"\tTURNO {ii++}");
                                    Console.WriteLine($"\tSeleccione su ataque:\n");
                                    Console.WriteLine("_____________________________________________________________________________________________");

                                    foreach (var atkb in red.SELECT_ATAQUE(b))//usa la lista del ataque seleccionado por el metodo selectATACK()
                                    {
                                        crt = crit(crt);
                                        efe = EFECTIVOa(b, a, efe);
                                        Console.WriteLine($"********************************************************************************************");
                                        Console.WriteLine($"Seleccione su ataque:\n");
                                        Console.WriteLine($"{bb.nombre} ataca con {atkb.ataque} que hace un daño de {atkb.dmg}\n");

                                        Console.WriteLine($"\nDAMAGE TOTAL: {atkb.dmg * efe * crt} !!!");//si hay criticp p efectivo se agraga
                                        alerta(crt, efe);

                                        Console.WriteLine($"{aa.nombre} tiene defensa de {aa.def} \n");//RECIBE ATAQUE
                                        Console.WriteLine($"Reduce el ataque de {atkb.dmg * efe * crt} en {Math.Round(atkb.dmg * efe * crt - (atkb.dmg * efe * crt * bb.def))}\n");
                                        Console.WriteLine($"La vida de {aa.nombre} se reduce a {Math.Round(aa.Hp = aa.Hp - (atkb.dmg * efe * crt - (atkb.dmg * efe * crt * aa.def)))}\n");
                                        crt = 1; efe = 1;//REESTALECER VALORES DE CRITICO Y EFECCTIVO
                                    }
                                    if (aa.Hp <= 0)
                                    {
                                        ash.endA();

                                    }
                                    if (bb.Hp <= 0)
                                    {
                                        red.endB();
                                    }
                                    petateado(a, b, y); y = exit(a, b, y);

                                    if (y == false)
                                    {
                                        break;
                                    }
                                    foreach (var atk in ash.SELECT_ATAQUE(a))//turno a
                                    {
                                                    Console.WriteLine($"turno para:  {ash.nombre}");

                                        crt = crit(crt); efe = EFECTIVOa(a, b, efe);

                                        Console.WriteLine($"\nDAMAGE TOTAL:  {atk.dmg * efe * crt}");
                                        alerta(crt, efe);

                                        Console.WriteLine($"{bb.nombre} tiene defensa de {bb.def} \n");
                                        Console.WriteLine($"Reduce el daño del ataque de {atk.dmg * efe * crt} en {Math.Round(atk.dmg * efe * crt - (atk.dmg * efe * crt * bb.def))}");
                                        Console.WriteLine($"La vida de {bb.nombre} se reduce a {Math.Round(bb.Hp = bb.Hp - (atk.dmg * efe * crt - (atk.dmg * efe * crt * bb.def)))}\n");
                                        exit(a, b, y);
                                        crt = 1; efe = 1;//REESTALECER VALORES DE CRITICO Y EFECCTIVO
                                    }
                                    if (aa.Hp <= 0)
                                    {
                                        ash.endA();

                                    }
                                    if (bb.Hp <= 0)
                                    {
                                        red.endB();
                                    }
                                    petateado(a, b, y); y = exit(a, b, y);

                                    cambioA = cambio1(a, cambioA);


                                    if (y == false)
                                    {
                                        break;
                                    }
                                    if (cambioA == false)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Yellow;
                                        Console.WriteLine($"Cambio de pokemon!!!");
                                        Console.ForegroundColor = ConsoleColor.White;
                                        break;
                                    }
                                    cambioB = cambio2(a, cambioB);
                                    if (cambioB == false)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Yellow;
                                        Console.WriteLine($"Cambio de pokemon!!!");
                                        Console.ForegroundColor = ConsoleColor.White;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                } while (relevo == true);

            } while (EXIT == true);
        }
    }
}