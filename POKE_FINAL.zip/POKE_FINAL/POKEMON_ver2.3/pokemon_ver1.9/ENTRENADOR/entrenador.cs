using System.Collections.Generic;
using System.Threading;
using System;
namespace POKEMON_ver1
{
    // Clase del entrenador
    public class entrenador
    {
        // Parametros de nuestra clase 
        public string nombre;

        // Diccionarios donde podemos almacenar las elecciones de nuestros pokemones en diferentes Team
        public static Dictionary<string, List<poke>> TEAM1 = new Dictionary<string, List<poke>> { };//POKEMON
        public static Dictionary<string, List<poke>> TEAM2 = new Dictionary<string, List<poke>> { };//SE ALMACENARAN 
        public static Dictionary<string, List<poke>> TEAM3 = new Dictionary<string, List<poke>> { };//LAS COLECCIONES 
        public static Dictionary<string, List<poke>> TEAM4 = new Dictionary<string, List<poke>> { };//DE 
        public static Dictionary<string, List<poke>> TEAM5 = new Dictionary<string, List<poke>> { };// CADA 
        public static Dictionary<string, List<poke>> TEAM6 = new Dictionary<string, List<poke>> { };//POKEMON
        public static Dictionary<string, List<poke>> uno = new Dictionary<string, List<poke>>(RETORNO_POKEMON());//POKEMON
        public static Dictionary<string, List<poke>> dos = new Dictionary<string, List<poke>>(RETORNO_POKEMON());//POKEMON
        public static Dictionary<string, List<poke>> tres = new Dictionary<string, List<poke>>(RETORNO_POKEMON());//POKEMON
        public static Dictionary<string, List<poke>> cuatro = new Dictionary<string, List<poke>>(RETORNO_POKEMON());//POKEMON
        public static Dictionary<string, List<poke>> cinco = new Dictionary<string, List<poke>>(RETORNO_POKEMON());//POKEMON
        public static Dictionary<string, List<poke>> seis = new Dictionary<string, List<poke>>(RETORNO_POKEMON());//POKEMON

        //CONSTRUCTOR ENTRENADOR
        public entrenador(string nombre)
        {
            this.nombre = nombre;
        }

        public entrenador(Dictionary<string, List<poke>> uno, Dictionary<string, List<poke>> dos, Dictionary<string, List<poke>> tres)
        {
        }

        // METODO CAMBIO DE POKEMON

        public virtual IEnumerable<poke> SELECT_ATAQUE(Dictionary<string, List<poke>> a)
        {

            int i = 0;
            string y;
            foreach (var n in a["S"])
            {
                foreach (var item1 in a["1"])
                {
                    foreach (var item2 in a["2"])
                    {
                        foreach (var item3 in a["3"])
                        {

                            do
                            {
                                Console.WriteLine($"********************************************************************************************");
                                Console.ForegroundColor = ConsoleColor.DarkBlue;
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.WriteLine($"********************************************************************************************\n\n");
                                Console.WriteLine($"*\tAtaque 1: {item1.ataque}\t Daño: {item1.dmg}");
                                Console.WriteLine($"*\tAtaque 2: {item2.ataque}\t Daño: {item2.dmg}");
                                Console.WriteLine($"*\tAtaque 3: {item3.ataque}\t Daño: {item3.dmg}\n\n");
                                Console.WriteLine($"********************************************************************************************");
                                Console.WriteLine($"-> ");

                                i = Convert.ToInt32(Console.ReadLine());

                                if (i <= 0 || i > 3)
                                {
                                    Console.WriteLine("Eleccion invalida, vuelva a elegir ataque");
                                }

                            } while (i <= 0 || i > 3);

                        }
                    }
                }
            }
            y = i.ToString();

            /* VARIABLE QUE NOS PEDIRA A TRAVES DEL TECLADO QUE SELECCIONEMOS UNO DE LOS 3 ATAQUES DISPONIBLES DE NUESTRO POKEMON ELEGIDO */
            Console.WriteLine($"\t\tATAQUE SELECCIONADO: ");
            IEnumerable<poke> aax = from x in a[y] select x; //a = PARAMETRO DEL METODO Y i = VARIABLE QUE NOS PERMITE ELEGIR ATAQUE
            return aax; // RETORNO DEL IENUMERABLE
        }

        //SELECCION DE DICCIONARIO ASIGNADO A POKEMONES
        public Dictionary<string, List<poke>> SELECION_DE_PELEADORa()
        {//selecciona un pokemon que viene del metodo retorno que se usa 3 veces
            int op = 0;
            Dictionary<string, List<poke>> a; Dictionary<string, List<poke>> b; Dictionary<string, List<poke>> c;

            a = uno;
            b = dos;
            c = tres;

            Console.WriteLine($" selecciona tu pokemon, entrenador:" + nombre);

            int i = 1;
            Console.WriteLine();
            IEnumerable<poke> HPa = from h in a["S"] select h;
            IEnumerable<poke> HPb = from h in b["S"] select h;
            IEnumerable<poke> HPc = from h in c["S"] select h;
            foreach (var itemA in HPa)
            {
                foreach (var itemB in HPb)
                {
                    foreach (var itemC in HPc)
                    {
                        if ((itemA.Hp > 0 && itemB.Hp > 0 && itemC.Hp > 0))
                        {

                            do
                            {
                                if (itemA.Hp > 0)
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("|----------------------------------------");
                                    Console.WriteLine($"|");

                                    Console.WriteLine($"| 1-) Pokemon {itemA.nombre} disponible           ");
                                }
                                if (itemB.Hp > 0)
                                {
                                    Console.WriteLine($"| 2-) Pokemone {itemB.nombre} disponible      ");
                                }
                                if (itemC.Hp > 0)
                                {
                                    Console.WriteLine($"| 3-) Pokemon {itemC.nombre} disponible      ");

                                }
                                Console.WriteLine($"|");
                                Console.WriteLine($"| Seleccione a quien desea utilizar      ");
                                Console.WriteLine($"|");
                                Console.WriteLine($"\n|----------------------------------------");
                                op = Convert.ToInt32(Console.ReadLine());
                                Console.ForegroundColor = ConsoleColor.White;


                                if (op <= 0 || op > 3)
                                {
                                    Console.WriteLine("$\nHa ingresado un dato incorrecto\n");
                                }


                            } while (op <= 0 || op > 3);

                            switch (op)
                            {
                                case 1:
                                    return a;

                                case 2:
                                    return b;

                                case 3:
                                    return c;

                            }
                        }
                        //cuando solo un pokemon a sido abatido
                        if ((itemA.Hp <= 0 && itemB.Hp > 0 && itemC.Hp > 0 ||
                            itemB.Hp <= 0 && itemA.Hp > 0 && itemC.Hp > 0 ||
                            itemC.Hp <= 0 && itemA.Hp > 0 && itemB.Hp > 0))
                        {

                            do
                            {
                                if (itemA.Hp > 0)
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("|----------------------------------------");
                                    Console.WriteLine($"|");

                                    Console.WriteLine($"| 1-) Pokemone {itemA.nombre} disponible           ");
                                }
                                if (itemB.Hp > 0)
                                {
                                    Console.WriteLine($"| 2-) Pokemone {itemB.nombre} disponible      ");
                                }
                                if (itemC.Hp > 0)
                                {
                                    Console.WriteLine($"| 3-) Pokemone {itemC.nombre} disponible      ");
                                    Console.WriteLine($"|");

                                    Console.WriteLine($"| Seleccione a quien desea utilizar      ");
                                    Console.WriteLine($"|");

                                    Console.WriteLine("|----------------------------------------");
                                    op = Convert.ToInt32(Console.ReadLine());
                                    Console.ForegroundColor = ConsoleColor.White;
                                }

                                if (op <= 0 || op > 3)
                                {
                                    Console.WriteLine("Ha ingresado un dato incorrecto");
                                }


                            } while (op <= 0 || op > 3);

                            switch (op)
                            {
                                case 1:
                                    return a;

                                case 2:
                                    return b;

                                case 3:
                                    return c;
                            }
                        }

                        if (itemA.Hp > 0)
                        {
                            Console.WriteLine($"1) Solo el pokemone {itemA.nombre} esta disponible \n suerte vaquero"); Console.ReadKey(); return a;
                        }

                        if ( itemB.Hp > 0)
                        {
                            Console.WriteLine($"2) Solo el pokemone {itemB.nombre} esta disponible \n suerte vaquero"); Console.ReadKey(); return b;
                        }

                        if ( itemC.Hp > 0)
                        {
                            Console.WriteLine($"3) Solo el pokemone {itemC.nombre} esta disponible \n suerte vaquero"); Console.ReadKey(); return c;

                        }
                    }

                }

            }
            return null;
        }





        public Dictionary<string, List<poke>> SELECION_DE_PELEADORb()
        {//selecciona un pokemon que viene del metodo retorno que se usa 3 veces
            int op = 1;
            Dictionary<string, List<poke>> a; Dictionary<string, List<poke>> b; Dictionary<string, List<poke>> c; string n = nombre;
            a = cuatro;
            b = cinco;
            c = seis;
            Console.WriteLine($" selecciona tu pokemon, entrenador:" + nombre);

            int i = 1;
            Console.WriteLine();
            IEnumerable<poke> HPa = from h in a["S"] select h;
            IEnumerable<poke> HPb = from h in b["S"] select h;
            IEnumerable<poke> HPc = from h in c["S"] select h;
            foreach (var itemA in HPa)
            {
                foreach (var itemB in HPb)
                {
                    foreach (var itemC in HPc)
                    {
                        if ((itemA.Hp > 0 && itemB.Hp > 0 && itemC.Hp > 0))
                        {

                            do
                            {
                                if (itemA.Hp > 0)
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("|----------------------------------------");
                                    Console.WriteLine($"|");

                                    Console.WriteLine($"| 1-) Pokemone {itemA.nombre} disponible           ");
                                }
                                if (itemB.Hp > 0)
                                {
                                    Console.WriteLine($"| 2-) Pokemone {itemB.nombre} disponible      ");
                                }
                                if (itemC.Hp > 0)
                                {
                                    Console.WriteLine($"| 3-) Pokemone {itemC.nombre} disponible      ");
                                    Console.WriteLine($"|");
                                }

                                Console.WriteLine($"| Seleccione a quien desea utilizar      ");
                                Console.WriteLine($"|");

                                Console.WriteLine("|----------------------------------------");
                                op = Convert.ToInt32(Console.ReadLine());
                                Console.ForegroundColor = ConsoleColor.White;


                                if (op <= 0 || op > 3)
                                {
                                    Console.WriteLine($"\nHa ingresado un dato incorrecto\n");
                                }


                            } while (op <= 0 || op > 3);

                            switch (op)
                            {
                                case 1:
                                    return a;

                                case 2:
                                    return b;

                                case 3:
                                    return c;

                            }
                        }
                        //cuando solo un pokemon a sido abatido
                        if ((itemA.Hp <= 0 && itemB.Hp > 0 && itemC.Hp > 0 ||
                            itemB.Hp <= 0 && itemA.Hp > 0 && itemC.Hp > 0 ||
                            itemC.Hp <= 0 && itemA.Hp > 0 && itemB.Hp > 0))
                        {

                            do
                            {
                                if (itemA.Hp > 0)
                                {
                                    Console.ForegroundColor = ConsoleColor.Cyan;
                                    Console.WriteLine("|----------------------------------------");
                                    Console.WriteLine($"|");

                                    Console.WriteLine($"| 1-) Pokemone {itemA.nombre} disponible           ");
                                }
                                if (itemB.Hp > 0)
                                {
                                    Console.WriteLine($"| 2-) Pokemone {itemB.nombre} disponible      ");
                                }
                                if (itemC.Hp > 0)
                                {
                                    Console.WriteLine($"| 3-) Pokemone {itemC.nombre} disponible      ");
                                    Console.WriteLine($"|");


                                }
                                Console.WriteLine($"| Seleccione a quien desea utilizar      ");
                                Console.WriteLine($"|");

                                Console.WriteLine("|----------------------------------------");
                                op = Convert.ToInt32(Console.ReadLine());
                                Console.ForegroundColor = ConsoleColor.White;

                                if (op <= 0 || op > 3)
                                {
                                    Console.WriteLine($"\nHa ingresado un dato incorrecto\n");
                                }


                            } while (op <= 0 || op > 3);

                            switch (op)
                            {
                                case 1:
                                    return a;

                                case 2:
                                    return b;

                                case 3:
                                    return c;

                            }

                        }


                        if ( itemA.Hp > 0)
                        {
                            Console.WriteLine($"1) Solo el pokemone {itemA.nombre} esta disponible \n suerte vaquero"); Console.ReadKey(); return a;
                        }

                        if ( itemB.Hp > 0)
                        {
                            Console.WriteLine($"2) Solo el pokemone {itemB.nombre} esta disponible \n suerte vaquero"); Console.ReadKey(); return b;
                        }

                        if ( itemC.Hp > 0)
                        {
                            Console.WriteLine($"3) Solo el pokemone {itemC.nombre} esta disponible \n suerte vaquero"); Console.ReadKey(); return c;

                        }
                    }
                }

            }return null;
        }
            
        



    public static Dictionary<string, List<poke>> RETORNO_POKEMON()//crea y devuelve un diccionario del pokemon seleccionado
    {
        // Objetos creados 
        onix ox = new onix();
        blastoise b = new blastoise();
        charizard c = new charizard();
        ivysour i = new ivysour();
        pikachu p = new pikachu();
        cubone cu = new cubone();//Console.ForegroundColor = ConsoleColor.White;
        int op;

        Console.ForegroundColor = ConsoleColor.DarkMagenta; Console.WriteLine("\n\t...POKEMONS DISPONIBLES....\n"); Console.ForegroundColor = ConsoleColor.White;
        do
        {
            Console.ForegroundColor = ConsoleColor.DarkMagenta; Console.WriteLine("Pokemones que tiene disponibles a elegir:"); Console.ForegroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkGray; Console.WriteLine("\n\t1.Onix"); Console.ForegroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkCyan; Console.WriteLine("\n\t2.Blastoide"); Console.ForegroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Red; Console.WriteLine("\n\t3.Charizar"); Console.ForegroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.Blue; Console.WriteLine("\n\t4.Ivysaur"); Console.ForegroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkYellow; Console.WriteLine("\n\t5.Pikachu"); Console.ForegroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkGreen; Console.WriteLine("\n\t6.Cubone"); Console.ForegroundColor = ConsoleColor.White;
            op = Convert.ToInt32(Console.ReadLine());

            if (op <= 0 || op > 6)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("\nSELECCION ERRONEA, INTENTE NUEVAMENTE\n");
                Console.ForegroundColor = ConsoleColor.White;
            }

        } while (op <= 0 || op > 6);




        if (op == 1)//Onix
        {
            TEAM1.Add("S", ox.stats_());//CREA Y DEVUELVE ESTADISTICAS 
            TEAM1.Add("D", ox.type_());//CREA Y DEVUELVE TIPO
            TEAM1.Add("1", ox.atk1_());//CREA Y DEVUELVE ATK 1
            TEAM1.Add("2", ox.atk2_());//CREA Y DEVUELVE ATK 2
            TEAM1.Add("3", ox.atk3_());//CREA Y DEVUELVE ATK 3
            IEnumerable<poke> a = from x in TEAM1["S"] select x;
            IEnumerable<poke> aa = from x in TEAM1["1"] select x;
            foreach (var item in a)
            {
                foreach (var items in aa)
                {//MANO DE GATO
                    Console.WriteLine("*********************************************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\t-> Has elegido el pokemon: {item.nombre} Tipo de pokemon: {item.tipo} y su pokemon tiene un porcentaje de vida de {item.Hp} hp");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("*********************************************************************************************************************************************************");
                }
            }
            return TEAM1;//RETORNA EL DICCIONARIO
        }
        if (op == 2)//Blastoide
        {
            TEAM2.Add("S", b.stats_());
            TEAM2.Add("D", b.type_());
            TEAM2.Add("1", b.atk1_());
            TEAM2.Add("2", b.atk2_());
            TEAM2.Add("3", b.atk3_());
            IEnumerable<poke> bx = from x in TEAM2["S"] select x;
            IEnumerable<poke> xb = from x in TEAM2["1"] select x;
            foreach (var item in bx)
            {
                foreach (var items in xb)
                {
                    Console.WriteLine("*********************************************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\t-> Has elegido el pokemon: {item.nombre} Tipo de pokemon: {item.tipo} y su pokemon tiene un porcentaje de vida de {item.Hp} hp");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("*********************************************************************************************************************************************************");
                }
            }
            return TEAM2;
        }

        if (op == 3)//Charizar
        {
            TEAM3.Add("S", c.stats_());
            TEAM3.Add("D", c.type_());
            TEAM3.Add("1", c.atk1_());
            TEAM3.Add("2", c.atk2_());
            TEAM3.Add("3", c.atk3_());
            IEnumerable<poke> cx = from x in TEAM3["S"] select x;
            IEnumerable<poke> xc = from x in TEAM3["1"] select x;
            foreach (var item in cx)
            {
                foreach (var items in xc)
                {//MANO DE GATO
                    Console.WriteLine("*********************************************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\t-> Has elegido el pokemon: {item.nombre} Tipo de pokemon: {item.tipo} y su pokemon tiene un porcentaje de vida de {item.Hp} hp");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("*********************************************************************************************************************************************************");
                }
            }
            return TEAM3;
        }

        if (op == 4)//Ivysaur
        {
            TEAM4.Add("S", i.stats_());
            TEAM4.Add("D", i.type_());
            TEAM4.Add("1", i.atk1_());
            TEAM4.Add("2", i.atk2_());
            TEAM4.Add("3", i.atk3_());
            IEnumerable<poke> a = from x in TEAM4["S"] select x;
            IEnumerable<poke> aa = from x in TEAM4["1"] select x;
            foreach (var item in a)
            {
                foreach (var items in aa)
                {
                    Console.WriteLine("**********************************************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\t-> Has elegido el pokemon: {item.nombre} Tipo de pokemon: {item.tipo} y su pokemon tiene un porcentaje de vida de {item.Hp} hp");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("*********************************************************************************************************************************************************");
                }
                return TEAM4;
            }

        }

        if (op == 5)//Pikachu
        {
            TEAM5.Add("S", p.stats_());
            TEAM5.Add("D", p.type_());
            TEAM5.Add("1", p.atk1_());
            TEAM5.Add("2", p.atk2_());
            TEAM5.Add("3", p.atk3_());
            IEnumerable<poke> a = from x in TEAM5["S"] select x;
            IEnumerable<poke> aa = from x in TEAM5["1"] select x;
            foreach (var item in a)
            {
                foreach (var items in aa)
                {
                    Console.WriteLine("**********************************************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\t-> Has elegido el pokemon: {item.nombre} Tipo de pokemon: {item.tipo} y su pokemon tiene un porcentaje de vida de {item.Hp} hp");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("*********************************************************************************************************************************************************");
                }
            }
            return TEAM5;
        }

        if (op == 6)//Cubone
        {
            TEAM6.Add("S", cu.stats_());
            TEAM6.Add("D", cu.type_());
            TEAM6.Add("1", cu.atk1_());
            TEAM6.Add("2", cu.atk2_());
            TEAM6.Add("3", cu.atk3_());
            IEnumerable<poke> a = from x in TEAM6["S"] select x;
            IEnumerable<poke> aa = from x in TEAM6["1"] select x;
            foreach (var item in a)
            {
                foreach (var items in aa)
                {
                    Console.WriteLine("**********************************************************************************************************************************************************");
                    Console.ForegroundColor = ConsoleColor.Magenta;
                    Console.WriteLine($"\t-> Has elegido el pokemon: {item.nombre} Tipo de pokemon: {item.tipo} y su pokemon tiene un porcentaje de vida de {item.Hp} hp");
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.WriteLine("*********************************************************************************************************************************************************");
                }
            }
            return TEAM6;

        }
        return TEAM6;

    }

            public void endA()//fin del juego
        {
            Dictionary<string, List<poke>> R; Dictionary<string, List<poke>> b; Dictionary<string, List<poke>> c;
            R = uno;
            b = dos;
            c = tres;
            IEnumerable<poke> HPa = from h in R["S"] select h;
            IEnumerable<poke> HPb = from h in b["S"] select h;
            IEnumerable<poke> HPc = from h in c["S"] select h;
            foreach (var itemA in HPa)
            {
                foreach (var itemB in HPb)
                {
                    foreach (var itemC in HPc)
                    {
                        if ((itemA.Hp <= 0 && itemB.Hp <= 0 && itemC.Hp <= 0))
                        {
                            Console.WriteLine($"SIN POKEMONES DISPONIBLES \n\t GAME OVER...");
                            Console.WriteLine($"\tPRESS ANY KEY TO QUIT");
                            Console.ReadLine();
                            Environment.Exit(1);
                        }
                    }
                }
            }
        }

        public void endB()
        {
            Dictionary<string, List<poke>> R; Dictionary<string, List<poke>> b; Dictionary<string, List<poke>> c;

            R = cuatro;
            b = cinco;
            c = seis;

            IEnumerable<poke> HPa = from h in R["S"] select h;
            IEnumerable<poke> HPb = from h in b["S"] select h;
            IEnumerable<poke> HPc = from h in c["S"] select h;
            foreach (var itemA in HPa)
            {
                foreach (var itemB in HPb)
                {
                    foreach (var itemC in HPc)
                    {
                        if ((itemA.Hp <= 0 && itemB.Hp <= 0 && itemC.Hp <= 0))
                        {
                            Console.WriteLine($"SIN POKEMONES DISPONIBLES \n\t GAME OVER...");
                            Console.WriteLine($"\tPRESS ANY KEY TO QUIT");
                            Console.ReadLine();
                            Environment.Exit(1);


                        }
                    }
                }
            }

        }

    public void Welcome()
    {
        Console.WriteLine("\n\tBIENVENIDOS A TU JUEGO POKEMON\n");

    }
    public void indicaciones()
    {
        Console.ForegroundColor = ConsoleColor.DarkRed;
        Console.WriteLine($"IMPORTANTE!!!\n");
        Console.ForegroundColor = ConsoleColor.White;
        Console.ForegroundColor = ConsoleColor.DarkYellow;
        Console.WriteLine("- Son dos equipos, de 3 pokemons por entrenador");
        Console.WriteLine("- Las primeras 3 eleciones corresponden al primer entrenador");
        Console.WriteLine("- Las otras 3 pertenecen al segundo entrenador");
        Console.WriteLine("- Tienes la oprtunidad de cambiar de pokemon, en cada turno correspondiente");
        Console.WriteLine($"- Las batallas terminan ya sea que e entrenador se retire de esta, o tus 3 pokemons mueran\n");
        Console.ForegroundColor = ConsoleColor.White;

    }
    public void ingreso()
    {
        Console.ForegroundColor = ConsoleColor.DarkBlue;
        Console.WriteLine("******************************************************");
        Console.WriteLine("\tINGRESO DE NOMBRE DE LOS ENTRENADORES:");
        Console.WriteLine("******************************************************");
        Console.ForegroundColor = ConsoleColor.White;
    }
    public void entrenadorNAME()
    {
        Console.ForegroundColor = ConsoleColor.Magenta;
        Console.WriteLine("\nIngrese su nombre:");
        Console.WriteLine("___________________________________");
        nombre = Console.ReadLine();
        Console.ForegroundColor = ConsoleColor.White;
    }

    public void bola()
    {
        Console.WriteLine("                                       .::------::.");
        Console.WriteLine("                                :=+#%@@@@@@@@@@@@@@@@%#*=:");
        Console.WriteLine("                            :+%@@@@@@@@%%%%%%%%%%%%@@@@@@@@%+");
        Console.WriteLine("                         -*@@@@@@%%%%%%%%%%%%%%%%%%%%%%%%@@@@@@#=");
        Console.WriteLine("                      :*@@@@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%@@@@@*-");
        Console.WriteLine("                    :#@@@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%@@@@%-");
        Console.WriteLine("                  :#@@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%@@@%:");
        Console.WriteLine("                 +@@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%@@@*.");
        Console.WriteLine("               .%@@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%@@@@:");
        Console.WriteLine("              :@@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%@@@-");
        Console.WriteLine("             :@@@%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%@@@=");
        Console.WriteLine("            :@@@%%%%%%%%%%%%%%%%%%%%%%%@@@@@@@@@@@@%%%%%%%%%%%%%%%%%%%%%%%@@@-");
        Console.WriteLine("            %@@%%%%%%%%%%%%%%%%%%%%%@@@@@@@@@@@@@@@@@@%%%%%%%%%%%%%%%%%%%%%@@@");
        Console.WriteLine("           =@@@%%%%%%%%%%%%%%%%%%%@@@@@@@@@@@@@@@@@@@@@@%%%%%%%%%%%%%%%%%%%%@@*");
        Console.WriteLine("           %@@%%%%%%%%%%%%%%%%%%%@@@@@@@@*-:..:-+%@@@@@@@%%%%%%%%%%%%%%%%%%%@@@.");
        Console.WriteLine("          :@@@%%%%%%%%%%%%%%%%%%@@@@@@%-          -%@@@@@@@@@@@@@@@@@@@@@@@%@@@=");
        Console.WriteLine("          +@@%%%%%%%%%%%%%%%%%%@@@@@@@.             #@@@@@@@@@@@@@@@@@@@@@@@@@@#");
        Console.WriteLine("          *@@%%%%%%%%%%@@@@@@@@@@@@@@+              -@@@@@@@@@@@@@@@@@@@@@@@@@@%");
        Console.WriteLine("          *@@%%%@@@@@@@@@@@@@@@@@@@@@+              -@@@@@@@@@@@@@@@@@@@@@@@@@@%");
        Console.WriteLine("          =@@@@@@@@@@@@@@@@@@@@@@@@@@@.             %@@@@@#=====++++***##%@@@@@#");
        Console.WriteLine("          :@@@@@@@@@@@@@@@@@@@@%@@@@@@@-          -%@@@@@@.                 =@@=");
        Console.WriteLine("           %@@@@@@@@@@%#*+-:.   .%@@@@@@@*-:..:-+%@@@@@@%:                  #@@.");
        Console.WriteLine("           =@@@@#*=-.             +@@@@@@@@@@@@@@@@@@@@*.                  -@@+");
        Console.WriteLine("            %@@.                   .+%@@@@@@@@@@@@@@@+.                   .@@@");
        Console.WriteLine("            :@@%.                     .=+#%@@@@%#*=:                      #@@-");
        Console.WriteLine("             :@@%.                                                       #@@=");
        Console.WriteLine("              :@@%:                                                    .%@@-");
        Console.WriteLine("               .%@@=                                                  -@@%:");
        Console.WriteLine("                 +@@%:                                              :#@@*");
        Console.WriteLine("                  .#@@#:                                          :*@@%:");
        Console.WriteLine("                    :#@@#=                                      -#@@#-");
        Console.WriteLine("                      .+@@@#=.                               -*@@@*:");
        Console.WriteLine("                         -*@@@%+-.                      .-+#@@@#-");
        Console.WriteLine("                            :+#@@@@#*+--:..    ..::-=*#@@@@#+-");
        Console.WriteLine("                                .-+*#@@@@@@@@@@@@@@@@%*+-:");
        Console.WriteLine("                                       ..::-----::.");
    }


}
}