using System.Runtime.CompilerServices;
using System.Runtime.ConstrainedExecution;
using System.Reflection.Metadata;
using POKEMON_ver1;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class program
    {
        public static void Main(string[] args)
        {
            Console.Clear();
            entrenador ash = new entrenador("");
            entrenador Red= new entrenador("");
            poke oo = new poke();
            Console.ForegroundColor = ConsoleColor.Green;

            Console.Write("Cargado... ");
            using (var progress = new ProgressBar())
            {
                for (int i = 0; i <= 1000; i++)
                {
                    progress.Report((double)i / 100000);
                    Thread.Sleep(5);
                }
            }
            Console.WriteLine("Listo.");
            //llamado a la funcion para el mensaje de bienvenida
            ash.Welcome();
            //Llamado a la funciion que contiene las reglas de juego
            Red.indicaciones();
            //Llamado a la funcion para e dibujo de la bola de bienvenida
            ash.bola();
            //Console.ReadKey();
            Console.Clear();
            //Ingreso de nombres de los entrenadores
            ash.ingreso();
            //Lllamado a las eleciones de pokemons y batallas
            oo.prueba_ataque();
        }
    }
}